import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { BittrexService } from './../../services/bittrex.service';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import {UserService} from '../../services/user.service';
import {Router} from '@angular/router';
import {FlashMessagesService} from 'angular2-flash-messages';

declare var $: any;
@Component({
  selector: "app-userdashboard",
  templateUrl: "./userdashboard.component.html",
  styleUrls: ["./userdashboard.component.css"]
})
export class UserdashboardComponent implements OnInit {
  loadedCharacter: {};
  markets: any[];
  currency: any[];
  cuurencies: any[];
  multiple0: boolean = false;
  multiple1: boolean = true;
  options0: Array<any> = [];
  options1: Array<any> = [];
  selection: Array<string>;
  selectBox:any;
  marketBox:any;
  bid: any;
  ask:any;
  last:any;
  high:any;
  low:any;
  vol:any;
  sellMarketHistory: any;
  buyMarketHistory: any;
  allMarketHistory: any;
  btcList: any;
  ethList: any;
  usdtList: any;
  chooseCurrency: any;
  chooseMarket: any;

  form1: FormGroup;


  constructor(
    private bittrexService: BittrexService,
    private fb: FormBuilder,
    public userService:UserService,
    private router:Router,
    private flashMessage:FlashMessagesService
  ) {}
  ngOnInit() {
    this.chooseCurrency = 'BTC/ADT';
    this.chooseMarket = 'Bittrex';

    document.body.style.backgroundImage =
      'url("./../../../assets/frontend/img/bg.png")';
    document.body.style.backgroundRepeat = "no-repeat";
    document.body.style.backgroundPosition = "center";
    document.body.style.backgroundAttachment = "fixed";
    document.body.style.backgroundSize = "100% 100%";
    document.body.style.paddingTop = "80px";
    this.bittrexService.getMarketName('BTC-ADT');
    this.getCurrency();
    this.getMarkets();
    this.getMarketSummary();
    this.getMarketHistory();
  }

  getMarkets() {
    this.bittrexService.getMarkets().subscribe((data) => {
    var markets = [];
     if (data['error'] == false) {
       for (let i = 0; i < data.message.length; i++) {
        markets.push(data.message[i].exchangeapiName)
       }
        this.markets = markets;
      } 
    });
  }

  getCurrency(){
    this.bittrexService.getCurrency().subscribe((data) => {
      if (data['error'] == false) {
      let numOptions = data['list'].result;
      let opts = new Array(numOptions);
      var btclist = [];
      var ethlist = []; 
      var usdtlist = []; 
      for (let i = 0; i < numOptions.length; i++) {
        if (data['list'].result[i].MarketName.startsWith('BTC-')) {
          btclist.push(data['list'].result[i]);
        }
        if (data['list'].result[i].MarketName.startsWith('ETH-')) {
          ethlist.push(data['list'].result[i]);
        }
        if (data['list'].result[i].MarketName.startsWith('USDT')) {
          usdtlist.push(data['list'].result[i]);
        }
      }
        this.btcList = btclist;
        this.ethList = ethlist;
        this.usdtList = usdtlist;
    }
    });
    
  }
  getMarketSummary(){
    this.bittrexService.getMarketSummary().subscribe((data) => {
      if(data['error'] == false){
        this.high=data['list'].result[0].High;
        this.low=data['list'].result[0].Low;
        this.vol=data['list'].result[0].Volume;
        this.ask=data['list'].result[0].Ask;
        this.bid=data['list'].result[0].Bid;
      }
    });
    }
  
  getMarketHistory(){
    this.bittrexService.getMarketHistory().subscribe((data) => {
      if (data['error'] == false) {
        this.allMarketHistory = data['list'].result;
        var sellmarket = [];
        var buymarket = [];
        for (let i = 0; i < data['list'].result.length; i++) {
          if (data['list'].result[i].OrderType == 'BUY') {
            buymarket.push(data['list'].result[i]);
          }
          if (data['list'].result[i].OrderType == 'SELL') {
            sellmarket.push(data['list'].result[i]);
          }
        }
        this.buyMarketHistory = buymarket;
        this.sellMarketHistory = sellmarket;
      }
    });
  }
   
  currencySelected(currencyName: any) {
    this.bittrexService.getMarketName(currencyName);
    this.chooseCurrency=currencyName;
  }
  marketSelected(marketName: any) {
    console.log(marketName)
  }

  onLogoutClick(){
    this.userService.logout();
    this.flashMessage.show('You are logged out', {cssClass:'alert-success', timeout: 3000});
    this.router.navigate(['/login']);
    return false;
  }
}

