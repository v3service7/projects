var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var Restaurant = require('../model/Restaurant.js');

// create a schema
var PromotionSchema = new Schema({
    image:  { type: String, required: true},
    name: { type: String, required: true},
    desc:  { type: String, required: true},
    restaurantOptions : [{ type: Schema.Types.ObjectId, ref:'Restaurant', required: true}]
});

var Promotion = mongoose.model('Promotion', PromotionSchema);

module.exports = Promotion;